import React from "react";
import { makeId } from "../storage";
import { Plus, Trash2, Layers } from "lucide-react";
import { Inputs, ExtraLayer, LayerRole } from "../engine";
import { fixtureTypes } from "../data/catalog";
import { NumberField, SelectField, SetInput } from "./Fields";
export function LayerEditor({ input, set }: { input: Inputs; set: SetInput }) {
  function change(id: string, patch: Partial<ExtraLayer>) {
    set(
      "layers",
      input.layers.map((l) => (l.id === id ? { ...l, ...patch } : l)),
    );
  }
  return (
    <section className="layer-editor">
      <div className="subheading">
        Your lighting layers <Layers size={16} />
      </div>
      <p className="small muted">
        The primary fixture supplies ambient light. Add dedicated task, accent
        and decorative groups; their light is not automatically credited to the
        whole room.
      </p>
      {input.layers.map((l) => (
        <article className="layer-row" key={l.id}>
          <div className="layer-row-heading">
            <SelectField
              label="Layer"
              value={l.role}
              options={["Ambient", "Task", "Accent", "Decorative"]}
              onChange={(s) => change(l.id, { role: s as LayerRole })}
            />
            <button
              className="icon-btn"
              aria-label={`Remove ${l.role} layer`}
              onClick={() =>
                set(
                  "layers",
                  input.layers.filter((x) => x.id !== l.id),
                )
              }
            >
              <Trash2 size={15} />
            </button>
          </div>
          <SelectField
            label={`${l.role} fixture`}
            value={l.type}
            options={fixtureTypes}
            onChange={(s) => change(l.id, { type: s })}
          />
          <div className="three-col lower-row">
            <NumberField
              label={`${l.role} quantity`}
              value={l.quantity}
              onChange={(n) => change(l.id, { quantity: n })}
              max={1000}
            />
            <NumberField
              label={`${l.role} lumens per unit`}
              value={l.lumens}
              onChange={(n) => change(l.id, { lumens: n })}
              min={1}
              max={100000}
              unit="lm"
            />
            <NumberField
              label={`${l.role} watts per unit`}
              value={l.watts}
              onChange={(n) => change(l.id, { watts: n })}
              min={0.1}
              max={2000}
              unit="W"
              step={0.1}
            />
          </div>
          <label className="check-label">
            <input
              type="checkbox"
              checked={l.contributes}
              onChange={(e) => change(l.id, { contributes: e.target.checked })}
            />
            Credit this group to the average task-plane illuminance
          </label>
          {l.contributes && (
            <>
              <p className="small muted">
                Only enable for luminaires serving the same horizontal
                calculation area. Focal accents and mirror lighting generally
                should not be credited.
              </p>
              <div className="two-col">
                <NumberField
                  label={`${l.role} utilization factor`}
                  value={l.uf}
                  onChange={(n) => change(l.id, { uf: n })}
                  min={0.1}
                  max={1}
                  step={0.05}
                />
                <NumberField
                  label={`${l.role} maintenance factor`}
                  value={l.mf}
                  onChange={(n) => change(l.id, { mf: n })}
                  min={0.1}
                  max={1}
                  step={0.05}
                />
              </div>
            </>
          )}
        </article>
      ))}
      <button
        className="btn secondary"
        disabled={input.layers.length >= 12}
        onClick={() =>
          set("layers", [
            ...input.layers,
            {
              id: makeId(),
              role: "Task",
              type: "Table lamps",
              quantity: 1,
              lumens: 500,
              watts: 6,
              uf: 0.6,
              mf: 0.8,
              contributes: false,
            },
          ])
        }
      >
        <Plus size={15} />
        Add lighting group
      </button>
    </section>
  );
}
